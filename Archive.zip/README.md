# Claude Code session logger: installation guide

This package adds hooks to Claude Code. For every turn they save, into the project being worked on:

- the prompt and the answer, as `prompt-and-answer-N.md`;
- the same plus the tool calls, results and file changes, as `prompt-and-answer-N-detailed.md`;
- the raw events, as `events.jsonl`.

Files go to `<project>/personal/<MM-DD-YYYY>/<HH-MM>--<session>/`. Nothing leaves the machine. The `personal/` folder is hidden from git locally only.

This guide is written for a Claude Code session to carry out. Follow the steps in order, and run each check before moving on. Ask the user before any step that overwrites a file.

## What is in this folder

- `hooks/*.sh`: the five scripts. They go into `~/.claude/hooks/`.
- `settings-hooks.json`: the hook entries to merge into `~/.claude/settings.json`.

## Step 1: Check the prerequisites

Run these and confirm each one prints a path:

```
command -v bash && command -v git && command -v jq
```

If `jq` is missing, install it:

- **macOS:** `brew install jq`
- **Debian or Ubuntu:** `sudo apt install jq`
- **Fedora:** `sudo dnf install jq`
- **Windows:** `winget install jqlang.jq`, then reopen the terminal

**Windows only:** the hooks run in bash, so the terminal must be Git Bash (installed with Git for Windows, which Claude Code also needs). Check with `echo $BASH_VERSION` in that terminal. If `bash` resolves to `C:\Windows\System32\bash.exe`, that is WSL, and the hooks will not see the Windows files. Put Git Bash first on `PATH` or use its full path.

## Step 2: Copy the scripts

Use the user's home directory:

```
mkdir -p ~/.claude/hooks
cp hooks/*.sh ~/.claude/hooks/
```

Then remove Windows line endings, which break bash, and make the scripts executable:

```
for f in ~/.claude/hooks/*.sh; do tr -d '\r' < "$f" > "$f.tmp" && mv "$f.tmp" "$f"; done
chmod +x ~/.claude/hooks/*.sh
```

Do not run the `chmod` line on Windows. It has no effect there, and the line-ending step is the one that matters.

If `~/.claude/hooks/save-response.sh` already exists and is not from this package, stop and ask the user before overwriting it.

Check the copies:

```
for f in ~/.claude/hooks/*.sh; do bash -n "$f" && echo "ok $f"; done
```

Five `ok` lines must print.

## Step 3: Add the hooks to settings

First back up the current settings. If the file does not exist, create it as `{}`:

```
mkdir -p ~/.claude
[ -f ~/.claude/settings.json ] || echo '{}' > ~/.claude/settings.json
cp ~/.claude/settings.json ~/.claude/settings.json.bak
```

Then merge. This keeps every existing setting and every hook that belongs to someone else. It replaces only the entries that point at this package's scripts, so running it twice does not duplicate anything:

```
jq --slurpfile ours settings-hooks.json '
  ($ours[0].hooks) as $h
  | .hooks //= {}
  | reduce ($h | keys_unsorted[]) as $e (.;
      .hooks[$e] = (
        ((.hooks[$e] // [])
          | map(select(((.hooks // []) | map(.command // "") | any(test("hooks/(save-response|log-event)\\.sh"))) | not)))
        + $h[$e]))
' ~/.claude/settings.json > ~/.claude/settings.json.new && mv ~/.claude/settings.json.new ~/.claude/settings.json
```

On Windows, the `~` in the commands is expanded by Git Bash, which is what the hooks run in. If the hook fails with "file not found", replace `~` in `~/.claude/settings.json` with the absolute home path using forward slashes and double quotes, for example `bash "C:/Users/name/.claude/hooks/save-response.sh" || true`.

Check the result:

```
jq -e '.hooks | keys' ~/.claude/settings.json
jq -e '[.hooks[][].hooks[].command | select(test("hooks/(save-response|log-event)\\.sh"))] | length' ~/.claude/settings.json
```

The first command must list the five events: `PostToolUse`, `PostToolUseFailure`, `PreToolUse`, `Stop`, `UserPromptSubmit`. The second must print `5`: one entry per event, four pointing at `log-event.sh` and `Stop` pointing at `save-response.sh`. Check that other settings are still there, such as `model`, `env` and `theme`. Compare with the `.bak` file if anything is missing.

## Step 4: Test it

Make a throwaway repository and simulate one turn. This does not depend on the user's real session:

```
T=$(mktemp -d) && cd "$T" && git init -q repo && cd repo
SID=testabcd-0000-0000-0000-000000000000
send() { printf '%s' "$1" | bash ~/.claude/hooks/log-event.sh; }
send "{\"session_id\":\"$SID\",\"prompt_id\":\"p1\",\"cwd\":\"$PWD\",\"hook_event_name\":\"UserPromptSubmit\",\"prompt\":\"test\"}"
send "{\"session_id\":\"$SID\",\"prompt_id\":\"p1\",\"cwd\":\"$PWD\",\"hook_event_name\":\"PreToolUse\",\"tool_name\":\"Bash\",\"tool_use_id\":\"t1\",\"tool_input\":{\"command\":\"echo hi\"}}"
send "{\"session_id\":\"$SID\",\"prompt_id\":\"p1\",\"cwd\":\"$PWD\",\"hook_event_name\":\"PostToolUse\",\"tool_name\":\"Bash\",\"tool_use_id\":\"t1\",\"duration_ms\":1,\"tool_response\":{\"stdout\":\"hi\",\"stderr\":\"\"}}"
printf '%s' "{\"session_id\":\"$SID\",\"cwd\":\"$PWD\",\"hook_event_name\":\"Stop\",\"last_assistant_message\":\"done\"}" | bash ~/.claude/hooks/save-response.sh
find personal -name 'prompt-and-answer-1*.md' | sort
```

Two files must be listed: `prompt-and-answer-1.md` and `prompt-and-answer-1-detailed.md`. Their folder is named like `personal/<MM-DD-YYYY>/<HH-MM>--testabcd`. If nothing is listed, read `~/.claude/hooks/save-response.log` and report the error to the user before continuing.

Delete the throwaway repository with `rm -rf "$T"`.

## Step 5: Activate it in the real session

Open `/hooks` once in Claude Code, or restart it. Then send a prompt in a real project. A new folder should appear under `personal/` in that project. Tell the user the folder name and where it is.

## How the folder names work

- The name is `HH-MM--<first 8 characters of the session ID>`. `HH-MM` is the 24-hour local time of the first prompt of that session that day.
- A session keeps its folder for the rest of the day. A session resumed on another day gets a new folder in that day's folder.
- A folder can be renamed by adding text after the ID, for example `11-53--316843ed-billing-bugfix`. The hooks find it by the `HH-MM--<session>` start, so the suffix is safe.
- Do not change the `HH-MM--<session>` part. Doing so makes the hooks create a second folder.
- If one session has two folders on the same day, new prompts use the earlier one.

## Troubleshooting

- **`$'\r': command not found` in the log:** Step 2's line-ending command was skipped. Run it again.
- **`jq: command not found`:** jq is not on the `PATH` of that terminal. Reopen the terminal after installing it.
- **No folder appears:** read `~/.claude/hooks/save-response.log`. Then run Step 4 again, which shows whether the scripts work outside Claude Code.
- **Windows, "file not found" for the hook:** see the note in Step 3 about `~`.
- **Windows, paths like `/c/...` in the log:** that is expected. Git Bash uses that form.

## Uninstall

1. Restore `~/.claude/settings.json` from `~/.claude/settings.json.bak` if it exists. Otherwise remove the `hooks` entries that point at `hooks/save-response.sh` or `hooks/log-event.sh`.
2. Delete the scripts: `rm ~/.claude/hooks/save-response.sh ~/.claude/hooks/log-event.sh ~/.claude/hooks/render-log.sh ~/.claude/hooks/lib.sh`.
3. Optional: `rm -rf ~/.claude/hooks/state ~/.claude/hooks/save-response.log`.
4. Optional: delete `personal/` in each project to remove the saved logs.

## Privacy

- The saved files are plain text. Only the user's account can read them.
- Common secrets are masked before saving (bearer tokens, API keys, passwords, private keys, URL credentials). This is best effort. Check the files before sharing them.
- `personal/` is listed in each repository's `.git/info/exclude`. The shared `.gitignore` is not changed.

## Tested platforms

These steps were run on macOS. Linux should work the same way. Windows through Git Bash is written but has not been run, so Step 4 is the check to run there.
