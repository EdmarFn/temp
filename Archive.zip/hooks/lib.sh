#!/bin/bash
# Shared helpers for the audit-log hooks (log-event.sh, render-log.sh, save-response.sh).
# Source this file; it only defines functions/variables and prints nothing.

umask 077 # prompts, tool output and diffs may contain secrets: owner-only permissions

# jq on Windows writes CRLF line endings, which would leave a stray \r in every path and value.
# -b (binary) keeps LF. It is accepted, and does nothing, on macOS and Linux.
jq() { command jq -b "$@"; }

# Claude Code on Windows can send C:\ paths, which Git Bash needs as /c/ paths. Other paths pass through unchanged.
to_posix() {
  case "$1" in
    [A-Za-z]:*) printf '/%s%s' "$(printf '%s' "${1:0:1}" | tr 'A-Z' 'a-z')" "$(printf '%s' "${1:2}" | tr '\\' '/')" ;;
    *) printf '%s' "$1" ;;
  esac
}

HOOKS_DIR="$HOME/.claude/hooks"
STATE_DIR="$HOOKS_DIR/state"
MAX_BYTES=20000 # per-string cap for tool inputs/outputs in the log

log() { printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >>"$HOOKS_DIR/save-response.log" 2>/dev/null; }

# resolve_paths <cwd> <session_id> [day]
# Sets ROOT (git root, else cwd), IN_REPO, DAY (MM-DD-YYYY) and DIR (<root>/personal/<day>/<HH-MM>--<session8>, reused if the session already has one that day).
resolve_paths() {
  local cwd=$1 sid=$2 short today hhmm winner
  [ -d "$cwd" ] || return 1
  ROOT=$(git -C "$cwd" rev-parse --show-toplevel 2>/dev/null)
  IN_REPO=1
  if [ -z "$ROOT" ]; then
    ROOT=$cwd
    IN_REPO=0
  fi
  # Day and time come from one clock read, so a folder created at 00:00 cannot land in the previous day's folder.
  IFS='|' read -r today hhmm <<<"$(date '+%m-%d-%Y|%H-%M')"
  DAY=${3:-$today}
  # Session ID part = first 8 chars of the session ID, safe charset only (no path traversal).
  short=$(printf '%s' "${sid:0:8}" | tr -cd 'A-Za-z0-9_-')
  short=${short:-unknown}
  DIR=$(find_session_dir "$ROOT/personal/$DAY" "$short")
  if [ -z "$DIR" ]; then
    # First hook of this session today: the folder name carries the creation time (HH-MM, 24h, local).
    DIR="$ROOT/personal/$DAY/$hhmm--$short"
    mkdir -p "$DIR" 2>/dev/null
    # Two hooks of a new session can race here (e.g. parallel tool calls): keep the earliest folder, drop ours if empty.
    winner=$(find_session_dir "$ROOT/personal/$DAY" "$short")
    if [ -n "$winner" ] && [ "$winner" != "$DIR" ]; then
      rmdir "$DIR" 2>/dev/null
      DIR=$winner
    fi
  fi
}

# find_session_dir <day-dir> <session8>: prints the existing folder of this session inside one day folder, if any.
# Contract: a folder belongs to the session when its name STARTS WITH "HH-MM--<session8>"; anything after that is free
# text, so the folder can be renamed to e.g. 11-53--316843ed-billing-bugfix without losing the session. The time part
# is ignored when matching, the earliest HH-MM wins, and a bare <session8> folder (old naming) is still recognised.
# Another day's folder is never matched, so a session resumed on a later day gets a new folder there.
find_session_dir() {
  local LC_COLLATE=C d # fixed collation: "earliest" must not depend on the locale of the calling process
  if [ "${#2}" -ge 8 ]; then
    # Real session IDs are 8+ hex chars, so a prefix match cannot hit another session.
    for d in "$1"/[0-2][0-9]-[0-5][0-9]--"$2"* "$1/$2"; do
      [ -d "$d" ] && { printf '%s' "$d"; return 0; }
    done
  else
    # Shorter (malformed) IDs: require the ID to end the name or be followed by a separator.
    for d in "$1"/[0-2][0-9]-[0-5][0-9]--"$2" "$1"/[0-2][0-9]-[0-5][0-9]--"$2"-* "$1"/[0-2][0-9]-[0-5][0-9]--"$2"_* "$1/$2"; do
      [ -d "$d" ] && { printf '%s' "$d"; return 0; }
    done
  fi
  return 0
}

# ensure_exclude <cwd>: keep <repo>/personal out of git locally, without touching the shared .gitignore.
# Anchored with a leading slash so it never matches a nested directory named "personal".
ensure_exclude() {
  local cwd=$1 exclude
  [ "${IN_REPO:-0}" = 1 ] || return 0
  exclude=$(cd "$cwd" && git rev-parse --git-path info/exclude 2>/dev/null)
  case "$exclude" in /*) ;; *) exclude="$cwd/$exclude" ;; esac # relative on git < 2.31
  if mkdir -p "$(dirname "$exclude")" 2>/dev/null; then
    grep -qxF '/personal/' "$exclude" 2>/dev/null || echo '/personal/' >>"$exclude"
  fi
}

# jq definitions: best-effort secret redaction + size clipping. Prepend to any jq program that writes log data.
# shellcheck disable=SC2016
JQ_SANITIZE='
def clip: if type=="string" and (utf8bytelength > $maxbytes)
  then .[0:$maxbytes] + "…[truncated " + ((utf8bytelength - $maxbytes) | tostring) + " bytes]" else . end;
def redact: if type=="string" then
    gsub("(?<p>authorization[\"'"'"':= ]+(bearer|basic)\\s+)[A-Za-z0-9._~+/=-]+"; "\(.p)[REDACTED]"; "i")
  | gsub("(?<p>(api[_-]?key|secret|token|passwd|password|access[_-]?key|private[_-]?key)[\"'"'"']?\\s*[:=]\\s*[\"'"'"']?)[^\\s\"'"'"',;]{4,}"; "\(.p)[REDACTED]"; "i")
  | gsub("sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}"; "[REDACTED]")
  | gsub("-----BEGIN [A-Z ]*PRIVATE KEY-----[\\s\\S]*?-----END [A-Z ]*PRIVATE KEY-----"; "[REDACTED PRIVATE KEY]")
  | gsub("(?<p>://[^/\\s:@]+:)[^@\\s/]+@"; "\(.p)[REDACTED]@")
  else . end;
def sanitize: walk(if type=="string" then clip | redact else . end);
'
