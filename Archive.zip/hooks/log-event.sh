#!/bin/bash
# Audit-log hook for UserPromptSubmit / PreToolUse / PostToolUse / PostToolUseFailure.
# Appends one sanitized JSON line per event to <root>/personal/<day>/<session8>/events.jsonl.
# On UserPromptSubmit it also opens the "window" state (folder + git baseline) used by the Stop hook.
# Never blocks and never prints: always exits 0 (settings.json also wraps it in "|| true").

# shellcheck source=lib.sh
source "$HOME/.claude/hooks/lib.sh" || exit 0

input=$(cat)
# One jq call for the routing fields. 0x1f is a non-whitespace separator, so empty fields are preserved.
IFS=$'\x1f' read -r event sid cwd <<<"$(jq -r '[.hook_event_name, .session_id, .cwd] | map(. // "") | join("\u001f")' <<<"$input" 2>/dev/null)"
[ -z "$event" ] && exit 0
sid=$(printf '%s' "$sid" | tr -cd 'A-Za-z0-9_-') # used in file names: safe charset only
[ -n "$sid" ] || exit 0
[ -z "$cwd" ] && cwd=$PWD
cwd=$(to_posix "$cwd")

state="$STATE_DIR/$sid.json"
mkdir -p "$STATE_DIR" 2>/dev/null

# State is kept from the first prompt after the previous Stop until the next Stop, so queued prompts, interrupted
# turns (Stop never fires) and the event window all stay consistent. A state older than 12h is considered stale.
state_fresh=0
if [ -f "$state" ]; then
  started=$(jq -r '.started // 0' "$state" 2>/dev/null)
  [ $(($(date +%s) - ${started:-0})) -lt 43200 ] && state_fresh=1
fi

if [ "$event" = "UserPromptSubmit" ] && [ "$state_fresh" = 0 ]; then
  resolve_paths "$cwd" "$sid" || { log "log-event: cwd does not exist: $cwd"; exit 0; }
  ensure_exclude "$cwd"
  mkdir -p "$DIR" || { log "log-event: mkdir failed: $DIR"; exit 0; }

  # Git baseline for the net diff: a commit of the current tracked state (no refs, working tree untouched),
  # or HEAD when the tree is clean; plus the untracked file list so new files can be told apart at Stop.
  baseline=""
  if [ "$IN_REPO" = 1 ]; then
    baseline=$(GIT_OPTIONAL_LOCKS=0 git -C "$ROOT" stash create 2>/dev/null)
    [ -z "$baseline" ] && baseline=$(git -C "$ROOT" rev-parse HEAD 2>/dev/null)
    GIT_OPTIONAL_LOCKS=0 git -C "$ROOT" -c core.quotepath=off ls-files -o --exclude-standard >"$STATE_DIR/$sid.untracked" 2>/dev/null
  fi
  jq -n --arg root "$ROOT" --arg dir "$DIR" --arg day "$DAY" --argjson in_repo "$IN_REPO" --arg baseline "$baseline" --argjson started "$(date +%s)" \
    '{root:$root, dir:$dir, day:$day, in_repo:($in_repo==1), baseline:$baseline, started:$started}' >"$state.tmp.$$" && mv "$state.tmp.$$" "$state"
elif [ "$state_fresh" = 1 ]; then
  DIR=$(jq -r '.dir' "$state")
  # Folder renamed/removed since the turn started (e.g. by migrate-session-folders.sh): find the session folder again.
  [ -d "$DIR" ] || resolve_paths "$cwd" "$sid" || exit 0
else
  # No state (hook installed mid-session): fall back to today's folder.
  resolve_paths "$cwd" "$sid" || exit 0
fi
# No blind mkdir here: if the folder was renamed since the check above, recreating the old name would orphan an events.jsonl.
[ -d "$DIR" ] || exit 0

rec=$(jq -c --argjson maxbytes "$MAX_BYTES" "$JQ_SANITIZE"'
  . as $in
  | (if .hook_event_name=="UserPromptSubmit" then {event:"prompt"}
     elif .hook_event_name=="PreToolUse" then {event:"tool_start", tool_name, tool_input}
     elif .hook_event_name=="PostToolUse" then
       {event:"tool_end", status:"ok", tool_name, duration_ms, tool_response:(.tool_response | if type=="object" then del(.originalFile) else . end)}
     elif .hook_event_name=="PostToolUseFailure" then
       {event:"tool_end", status:(if .is_interrupt then "interrupted" else "error" end), tool_name, duration_ms, error}
     else empty end)
  + {ts: now, turn: $in.prompt_id, session: $in.session_id, agent_id: $in.agent_id, tool_use_id: $in.tool_use_id}
  | with_entries(select(.value != null))
  | sanitize' <<<"$input" 2>/dev/null)

# cat does a single large write(2) on an O_APPEND file, so concurrent hooks (parallel tool calls) cannot interleave lines;
# a buffered printf of a long line may be split into several writes.
[ -n "$rec" ] && cat <<<"$rec" >>"$DIR/events.jsonl"
exit 0
