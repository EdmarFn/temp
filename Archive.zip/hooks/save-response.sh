#!/bin/bash
# Stop hook: saves each prompt + answer, and a detailed twin with the execution log, to
#   <git-root>/personal/<MM-DD-YYYY>/<HH-MM>--<session8>/prompt-and-answer-N.md           (prompt + answer)
#   <git-root>/personal/<MM-DD-YYYY>/<HH-MM>--<session8>/prompt-and-answer-N-detailed.md  (same + execution log)
# HH-MM (24h, local) is when the first hook of that session ran that day; later turns find the folder by <session8>.
# Plain script, so it costs no LLM tokens. Never fails or blocks the turn (always exits 0).
# Tool events are collected by log-event.sh; the readable log is rendered by render-log.sh.
# Failures are appended to ~/.claude/hooks/save-response.log instead of being lost silently.

# shellcheck source=lib.sh
source "$HOME/.claude/hooks/lib.sh" || exit 0

input=$(cat)

session_id=$(jq -r '.session_id // empty' <<<"$input" 2>/dev/null)
transcript=$(jq -r '.transcript_path // empty' <<<"$input" 2>/dev/null)
cwd=$(jq -r '.cwd // empty' <<<"$input" 2>/dev/null)
answer=$(jq -r '.last_assistant_message // empty' <<<"$input" 2>/dev/null)

[ -z "$answer" ] && exit 0
[ -z "$cwd" ] && cwd=$PWD
cwd=$(to_posix "$cwd")
[ -d "$cwd" ] || { log "cwd does not exist: $cwd"; exit 0; }

# Folder and git baseline were fixed by log-event.sh at the first prompt since the last Stop, so a turn that crosses
# midnight stays in one folder. Without state (hook installed mid-session) fall back to today's folder.
session_id=$(printf '%s' "$session_id" | tr -cd 'A-Za-z0-9_-') # used in file names: safe charset only
state="$STATE_DIR/$session_id.json"
baseline=""
untracked=""
if [ -f "$state" ]; then
  DIR=$(jq -r '.dir' "$state")
  ROOT=$(jq -r '.root' "$state")
  # Folder renamed/removed since the turn started: find the session folder again.
  [ -d "$DIR" ] || resolve_paths "$cwd" "$session_id" || exit 0
  baseline=$(jq -r '.baseline // empty' "$state")
  untracked="$STATE_DIR/$session_id.untracked"
else
  resolve_paths "$cwd" "$session_id" || exit 0
  ensure_exclude "$cwd"
fi
[ -d "$DIR" ] || { log "session folder missing: $DIR"; exit 0; }

stamp=$(date '+%Y-%m-%d %H:%M:%S')

model="unknown"
prompt="(prompt not found)"
if [ -n "$transcript" ] && [ -f "$transcript" ]; then
  # Read line by line with fromjson? so a half-flushed last line cannot break the whole parse.
  # Model: last main-thread assistant message (skip subagent/sidechain and <synthetic> entries).
  m=$(jq -nRr '
    [inputs | fromjson? | select(type=="object")
     | select(.type=="assistant" and (.isSidechain // false | not))
     | .message.model // empty
     | select(. != "<synthetic>")
    ] | last // empty' "$transcript" 2>/dev/null)
  [ -n "$m" ] && model=$m

  # Prompt: last real user text. Skips tool results, meta entries, local-command output and interrupt markers.
  # Slash/skill invocations (<command-name>) are kept, since they are the prompt of that turn.
  p=$(jq -nRr '
    [inputs | fromjson? | select(type=="object")
     | select(.type=="user" and (.isMeta // false | not) and (.isSidechain // false | not))
     | .message.content
     | if type=="string" then .
       elif type=="array" then ([.[] | select(.type=="text") | .text] | join("\n"))
       else empty end
     | select(length > 0)
     | select(test("^\\s*<local-command-") | not)
     | select(test("^\\s*\\[Request interrupted") | not)
    ] | last // empty' "$transcript" 2>/dev/null)
  [ -n "$p" ] && prompt=$p
fi

# Tool calls, results, visible messages and file changes of this turn (empty when none were recorded).
exec_log=$(ANSWER="$answer" bash "$HOOKS_DIR/render-log.sh" "$DIR" "$transcript" "$ROOT" "$baseline" "$untracked" 2>/dev/null)

# Two files per turn, built privately first, then published with an atomic no-clobber link:
#   prompt-and-answer-N.md           header + prompt + answer (the clean document)
#   prompt-and-answer-N-detailed.md  the same, plus the execution log
# Readers never see a half-written file, and a concurrent session cannot overwrite ours.
tmp_clean=$(mktemp "$ROOT/personal/.tmp.XXXXXX") || { log "mktemp failed in $ROOT/personal"; exit 0; }
tmp_detail=$(mktemp "$ROOT/personal/.tmp.XXXXXX") || { log "mktemp failed in $ROOT/personal"; rm -f "$tmp_clean"; exit 0; }
trap 'rm -f "$tmp_clean" "$tmp_detail"' EXIT

# Next number = highest existing + 1, counting both file kinds so an orphaned -detailed file is never reused.
# Robust to deleted files; 10# avoids octal parsing of names like -08.
max=0
for f in "$DIR"/prompt-and-answer-*.md; do
  [ -e "$f" ] || continue
  n=${f##*prompt-and-answer-}
  n=${n%.md}
  n=${n%-detailed}
  [[ $n =~ ^[0-9]+$ ]] && ((10#$n > max)) && max=$((10#$n))
done
n=$((max + 1))

# publish <tmp> <target>: atomic no-clobber. Hard link first; mv -n on filesystems without hard links.
publish() {
  ln "$1" "$2" 2>/dev/null && return 0
  [ ! -e "$2" ] && mv -n "$1" "$2" 2>/dev/null && [ ! -e "$1" ]
}

header_body() {
  printf '# Prompt and Answer %s\n\n- **Date:** %s\n- **Model:** %s\n- **Session:** %s\n- **Project:** %s\n\n## Prompt\n\n%s\n\n## Answer\n\n%s\n' \
    "$n" "$stamp" "$model" "${session_id:-unknown}" "$ROOT" "$prompt" "$answer"
}

saved=0
for _ in $(seq 1 50); do
  # The folder may have been renamed (e.g. a topic suffix added) since it was resolved: look it up again.
  [ -d "$DIR" ] || resolve_paths "$cwd" "$session_id" || break
  clean="$DIR/prompt-and-answer-$n.md"
  detail="$DIR/prompt-and-answer-$n-detailed.md"
  if [ -e "$clean" ] || [ -e "$detail" ]; then
    n=$((n + 1))
    continue
  fi
  header_body >"$tmp_clean" || { log "write failed: $tmp_clean"; exit 0; }
  {
    header_body
    if [ -n "$exec_log" ]; then printf '\n%s\n' "$exec_log"; fi # `&&` would make an empty log look like a write failure
  } >"$tmp_detail" || { log "write failed: $tmp_detail"; exit 0; }
  # Detailed first, so a visible clean file always has its detailed twin. If the clean file loses a race, undo ours.
  if publish "$tmp_detail" "$detail"; then
    if publish "$tmp_clean" "$clean"; then
      saved=1
      break
    fi
    rm -f "$detail"
  fi
  n=$((n + 1))
done
[ "$saved" = 1 ] || log "could not allocate a file number in $DIR"

# Close the window: the marker tells render-log.sh where the next turn's events start; then drop the state.
[ "$saved" = 1 ] && cat <<<"$(jq -nc --arg s "$session_id" '{event:"stop", ts:now, session:$s}')" >>"$DIR/events.jsonl"
rm -f "$state" "$STATE_DIR/$session_id.untracked" 2>/dev/null

exit 0
