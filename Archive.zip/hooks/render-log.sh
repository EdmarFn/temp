#!/bin/bash
# Renders the "## Execution log" markdown section for one turn on stdout.
# Usage: ANSWER=<final answer> render-log.sh <dir> <transcript> <root> <baseline> <untracked_file>
# Window = events recorded since the previous "stop" marker in events.jsonl (so queued prompts and interrupted
# turns are included instead of lost). Sources: events.jsonl (tool calls/results), transcript (user-visible
# assistant text only), git (net changes). Model reasoning ("thinking" blocks) is never read.

# shellcheck source=lib.sh
source "$HOME/.claude/hooks/lib.sh" || exit 0

dir=$1 transcript=$2 root=$3 baseline=$4 untracked=$5
events="$dir/events.jsonl"
[ -f "$events" ] || exit 0

# fenced <lang> <body>: code fence one backtick longer than any backtick run in the body (min 4),
# so tool output containing ``` or ```` cannot break the markdown.
fenced() {
  local lang=$1 body=$2 run f
  run=$(printf '%s' "$body" | grep -o '`\{1,\}' | awk '{ if (length($0) > m) m = length($0) } END { print m + 0 }')
  [ "$run" -lt 3 ] && run=3
  f=$(printf '%*s' $((run + 1)) '' | tr ' ' '`')
  printf '%s%s\n%s\n%s\n' "$f" "$lang" "$body" "$f"
}

# Events after the last stop marker. Raw key text can only appear unescaped as a real key, never inside a string.
last_stop=$(grep -n '"event":"stop"' "$events" | tail -1 | cut -d: -f1)
ev=$(tail -n +$((${last_stop:-0} + 1)) "$events" | jq -cR 'fromjson? | select(type=="object" and .event != "stop")' 2>/dev/null | jq -cs . 2>/dev/null)
[ -n "$ev" ] && [ "$ev" != "[]" ] || exit 0

# Visible assistant text since the window started (subagent sidechains skipped); the final answer is shown elsewhere.
msgs='[]'
if [ -n "$transcript" ] && [ -f "$transcript" ]; then
  msgs=$(jq -nR --argjson ev "$ev" --arg answer "${ANSWER:-}" '
    def epoch: (capture("^(?<s>[^.]+)(\\.(?<f>[0-9]+))?Z$")) as $c
      | (($c.s + "Z") | fromdateiso8601) + (("0." + ($c.f // "0")) | tonumber);
    ($ev | map(.ts) | min) as $start
    | [inputs | fromjson? | select(type=="object")
       | select(.type=="assistant" and (.isSidechain // false | not) and (.timestamp | type) == "string")
       | (.timestamp | epoch) as $t | select($t >= $start)
       | .message.content[]? | select(.type=="text")
       | {kind:"message", ts:$t, text:.text}
       | select((.text | gsub("^\\s+|\\s+$"; "")) != ($answer | gsub("^\\s+|\\s+$"; "")))]' "$transcript" 2>/dev/null)
  [ -n "$msgs" ] || msgs='[]'
fi

echo "## Execution log"
echo

# shellcheck disable=SC2016
jq -nr --argjson ev "$ev" --argjson msgs "$msgs" '
  def hms: (tonumber? // 0) | localtime | strftime("%H:%M:%S");
  def esc: (. // "") | tostring | gsub("&"; "&amp;") | gsub("<"; "&lt;");
  def fence($lang; $body):
    (([$body | match("`+"; "g").length] | max // 0) + 1 | if . < 4 then 4 else . end) as $n
    | ("`" * $n) as $f | $f + $lang + "\n" + $body + "\n" + $f;
  def keyinput: (.input // {}) as $i
    | if .name == "Bash" then (($i.command // "") | split("\n")[0] // "" | .[0:120])
      elif $i.file_path then $i.file_path
      elif $i.pattern then $i.pattern
      elif $i.description then ($i.description | .[0:120])
      else "" end;
  def inputblock: (.input // {}) as $i
    | if .name == "Bash" then fence("bash"; $i.command // "")
      elif ($i.content != null and $i.file_path != null) then "File: `" + $i.file_path + "` (" + (($i.content | length) | tostring) + " chars written)"
      elif ($i.old_string != null and $i.file_path != null) then "File: `" + $i.file_path + "` (diff under Changes)"
      else fence("json"; ($i | tojson)) end;
  def resultblock:
    if .error != null then fence("text"; .error)
    elif .resp == null then "_no result recorded_"
    elif .name == "Bash" then fence("text"; ((.resp.stdout // "") + (if (.resp.stderr // "") != "" then "\n[stderr]\n" + .resp.stderr else "" end)))
    else fence("json"; (.resp | if type == "object" then del(.structuredPatch) else . end | tojson)) end;

  ([$ev[] | select((.event == "tool_start" or .event == "tool_end") and .tool_use_id != null)] | group_by(.tool_use_id) | map(
      (map(select(.event == "tool_start")) | .[0]) as $s
      | (map(select(.event == "tool_end")) | .[0]) as $e
      | ($s // $e) as $b
      | {kind: "tool", ts: $b.ts, name: $b.tool_name, agent: $b.agent_id, input: $s.tool_input,
         status: ($e.status // "no result"), dur: $e.duration_ms, resp: $e.tool_response, error: $e.error})) as $tools
  | ($tools + $msgs) | sort_by(.ts) | .[]
  | if .kind == "message" then
      "**\(.ts | hms) - Assistant**\n\n" + (.text | split("\n") | map("> " + .) | join("\n")) + "\n"
    else
      "<details>\n<summary><code>\(.ts | hms)</code> <b>\(.name | esc)</b>"
      + (if .agent then " (subagent)" else "" end) + " - \(.status)"
      + (if .dur then " - \(.dur) ms" else "" end)
      + (keyinput | if . != "" then " - <code>" + esc + "</code>" else "" end) + "</summary>\n\n"
      + "Input:\n\n" + inputblock + "\n\nResult:\n\n" + resultblock + "\n\n</details>\n"
    end' 2>>"$HOOKS_DIR/save-response.log"

# --- Changes: per-edit diffs from tool results (structuredPatch), then net git changes ---
changes=$(jq -nr --argjson ev "$ev" '
  def hms: (tonumber? // 0) | localtime | strftime("%H:%M:%S");
  def fence($lang; $body):
    (([$body | match("`+"; "g").length] | max // 0) + 1 | if . < 4 then 4 else . end) as $n
    | ("`" * $n) as $f | $f + $lang + "\n" + $body + "\n" + $f;
  [$ev[] | select(.event == "tool_end" and .status == "ok" and (.tool_name | test("^(Edit|Write|MultiEdit|NotebookEdit)$")))]
  | sort_by(.ts) | .[]
  | .tool_response as $r
  | "#### \(.ts | hms) \(.tool_name) `\($r.filePath // $r.file_path // $r.notebook_path // "")`" + (if $r.type == "create" then " (created)" else "" end) + "\n\n"
    + fence("diff"; (($r.structuredPatch // [])
        | map("@@ -\(.oldStart),\(.oldLines) +\(.newStart),\(.newLines) @@\n" + (.lines | join("\n"))) | join("\n"))
        | if . == "" then (($r.content // "") | if . == "" then "(no diff reported)" else split("\n") | map("+" + .) | join("\n") end) else . end) + "\n"' 2>>"$HOOKS_DIR/save-response.log")

net=""
newfiles=""
if [ -n "$baseline" ] && [ -d "$root" ]; then
  export GIT_OPTIONAL_LOCKS=0
  net=$(git -C "$root" diff --no-color "$baseline" -- 2>/dev/null | head -c 200000 \
    | jq -Rrs --argjson maxbytes 200000 "$JQ_SANITIZE"' clip | redact' 2>/dev/null)
  if [ -n "$untracked" ] && [ -f "$untracked" ]; then
    now_list=$(git -C "$root" -c core.quotepath=off ls-files -o --exclude-standard 2>/dev/null | sort)
    count=0
    while IFS= read -r f; do
      [ -z "$f" ] && continue
      count=$((count + 1))
      if [ "$count" -gt 50 ]; then
        newfiles+="- ... more new files omitted"$'\n'
        break
      fi
      p="$root/$f"
      if [ -L "$p" ]; then
        # Never inline what a new symlink points at (it could be outside the repo).
        newfiles+="- New symlink \`$f\` (target not shown)"$'\n'
        continue
      fi
      size=$(wc -c <"$p" 2>/dev/null | tr -d ' ')
      if [ -n "$size" ] && [ "$size" -le "$MAX_BYTES" ] && grep -Iq . "$p" 2>/dev/null; then
        body=$(jq -Rrs --argjson maxbytes "$MAX_BYTES" "$JQ_SANITIZE"' clip | redact' <"$p" 2>/dev/null)
        newfiles+=$'\n'"#### New file \`$f\`"$'\n\n'"$(fenced '' "$body")"$'\n\n'
      else
        newfiles+="- New file \`$f\` (${size:-?} bytes, content not shown)"$'\n'
      fi
    done < <(comm -13 <(sort "$untracked") <(printf '%s\n' "$now_list"))
  fi
fi

if [ -n "$changes" ] || [ -n "$net" ] || [ -n "$newfiles" ]; then
  echo "### Changes"
  echo
  if [ -n "$changes" ]; then
    echo "Per-edit diffs (from tool results):"
    echo
    printf '%s\n\n' "$changes"
  fi
  if [ -n "$net" ]; then
    echo "Net tracked-file changes (git diff since the turn started; includes deletions and changes made through Bash):"
    echo
    printf '%s\n\n' "$(fenced diff "$net")"
  fi
  [ -n "$newfiles" ] && printf '%s\n' "$newfiles"
fi
exit 0
